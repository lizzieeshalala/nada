﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PezMovimiento : MonoBehaviour
{
    public Animator anim;
    public float upForce;  
    private bool isDead;
    private Rigidbody2D rb2d;
    public float speed;

    void Start()
    {
        //click de mouse como flappy bird
        //upForce = 200f;

        isDead = false;

        //comentar para activar mouse como flappy bird
        speed = 3f;

        anim = gameObject.GetComponent<Animator>();
        rb2d = gameObject.GetComponent<Rigidbody2D>();
    }

     void Update()
    {
        if (isDead == false) 
        {
            //click de mouse como flappy bird
            /*if (Input.GetMouseButtonDown(0)) 
            {
                anim.SetTrigger("Swim");
                rb2d.velocity = Vector2.zero;
                rb2d.AddForce(new Vector2(0, upForce));
            }*/

            //comentar para activar mouse como flappy bird
            if (Input.GetKey(KeyCode.A))
            {
                transform.position += Vector3.left * speed * Time.deltaTime;
                anim.SetTrigger("Swim");
            }
            if (Input.GetKey(KeyCode.D))
            {
                transform.position += Vector3.right * speed * Time.deltaTime;
                anim.SetTrigger("Swim");
            }
            if (Input.GetKey(KeyCode.W))
            {
                transform.position += Vector3.up * speed * Time.deltaTime;
                anim.SetTrigger("Swim");
            }
            if (Input.GetKey(KeyCode.S))
            {
                transform.position += Vector3.down * speed * Time.deltaTime;
                anim.SetTrigger("Swim");
            }
        }
    }

    void OnCollisionEnter2D(Collision2D other)
    {
        rb2d.velocity = Vector2.zero;
        isDead = true;
        GameControl.instance.FishDied();
    }
}
